CREATE TABLE estudiante (
                          id INT(12) NOT NULL AUTO_INCREMENT,
                          nombre VARCHAR(20) NOT NULL,
                          apellido VARCHAR(20) NOT NULL,
                          edad int(4) NOT NULL,
                          PRIMARY KEY (id),
                          UNIQUE INDEX codigo (codigo)
)
