package Controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ar.com.codoacodo.daos.ProductoDAO;
import ar.com.codoacodo.dto.Producto;

@WebServlet("/api/EditarController")
public class EditarController extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String id = req.getParameter("id");

        //Crear EstudianteDAO
        EstudianteDAO dao = new EstudianteDAO();

        //invocar el metodo obtenerPorId(id)
        Estudiante estudFromDb = dao.obtenerPorId(Long.parseLong(id));

        //guardar en el request el producto
        req.setAttribute("estudiante", estudFromDb);

        //ir a la siguiente pagina
        getServletContext().getRequestDispatcher("/editar.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String nombre = req.getParameter("nombre");
        String apellido = req.getParameter("apellido");
        String edad = req.getParameter("edad");
        String codigo = req.getParameter("codigo");

        //Crear ProductoDAO
        EstudianteDAO dao = new EstudianteDAO();

        //invocar actualizarProducto(params)
        dao.actualizarEstudiante(codigo, nombre, apellido,edad);

        //ir a la siguiente pagina
        resp.sendRedirect(req.getContextPath()+"/api/ListadoController");
    }
}

